/**
 * 
 */
package com.mitra.java.adminLogin.controller;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.dao.DataAccessException;
import org.springframework.web.servlet.ModelAndView;

import com.mitra.java.adminLogin.model.AdminLoginBean;
import com.mitra.java.adminLogin.model.userDetailsBean;
import com.mitra.java.adminLogin.service.AdminLoginService;

/**
 * @author Imransham
 *
 */
@Controller
public class AdminLoginController implements AdminLoginService {

	@Autowired
	DataSource datasource;
	@Autowired
	JdbcTemplate jdbcTemplate;

	@Override
	public userDetailsBean validateUser(AdminLoginBean login) throws DataAccessException {
		System.out.println("control into validateUser");
		String sql = "select * from STUDENT where id='" + login.getUsername() + "' and name='" + login.getPassword()
				+ "'";
		List<userDetailsBean> users = jdbcTemplate.query(sql, new UserMapper());
		if (users.size() > 0)
			return users.get(0);
		else
			return null;
	}

	class UserMapper implements RowMapper<userDetailsBean> {
		public userDetailsBean mapRow(ResultSet rs, int arg1) throws SQLException {
			userDetailsBean user = new userDetailsBean();
			user.setUsername(rs.getString("username"));
			user.setPassword(rs.getString("password"));
			user.setFirstname(rs.getString("firstname"));
			user.setLastname(rs.getString("lastname"));
			user.setEmail(rs.getString("email"));
			user.setAddress(rs.getString("address"));
			user.setPhone(rs.getInt("phone"));
			return user;
		}
	}

	@RequestMapping(value = "/loginProcess", method = RequestMethod.POST)
	public String loginProcess(@ModelAttribute("login") AdminLoginBean login, BindingResult result, Model model) {
		try {
			System.out.println("control into loginProcess" + login.getUsername());
			/*
			 * ModelAndView mav = null; mav = new ModelAndView("welcome");
			 */
			/*
			 * userDetailsBean user = validateUser(login); if (null != user) {
			 * mav = new ModelAndView("welcome"); mav.addObject("firstname",
			 * user.getFirstname()); } else { mav = new ModelAndView("welcome");
			 * mav.addObject("message", "Username or Password is wrong!!"); }
			 */

		} catch (Exception e) {
			System.out.println("control into loginProcess" + e);
		}
		return "welcome";
	}

}
