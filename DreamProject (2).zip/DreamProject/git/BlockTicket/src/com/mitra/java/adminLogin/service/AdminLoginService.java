/**
 * 
 */
package com.mitra.java.adminLogin.service;

import com.mitra.java.adminLogin.model.AdminLoginBean;
import com.mitra.java.adminLogin.model.userDetailsBean;

/**
 * @author Imransha This interface used for logging admin pagea
 *
 */
public interface AdminLoginService {

	public userDetailsBean validateUser(AdminLoginBean login);

}