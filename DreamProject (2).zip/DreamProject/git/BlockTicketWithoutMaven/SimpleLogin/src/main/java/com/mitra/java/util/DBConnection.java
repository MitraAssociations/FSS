package com.mitra.java.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.springframework.dao.DataAccessException;

import com.mitra.java.adminLogin.model.AdminLoginBean;
public class DBConnection {
	public static Connection createConnection()
	{
		Connection con = null;
		String url = "jdbc:mysql://localhost:1521/orcl"; //MySQL URL and followed by the database name
		String username = "C##polaris"; //MySQL username
		String password = "polaris"; //MySQL password
		try 
		{
			try 
			{
				Class.forName("com.mysql.jdbc.Driver").newInstance(); //loading mysql driver 
			} 
			catch (ClassNotFoundException e)
			{
				System.out.println("Exception in ClassNotFoundException connection" + e.getMessage());
				e.printStackTrace();
			} 
			if(con == null) {
				con = DriverManager.getConnection(url, username, password); //attempting to connect to MySQL database
			} else {
				System.out.println("con already exists");
			}
			System.out.println("Printing connection object " + con);
		} 
		catch (Exception e) 
		{
			System.out.println("Exception in cgetting connection" + e.getMessage());
			e.printStackTrace();
		}
		return con; 
	}

	public String validateUser(AdminLoginBean login) throws DataAccessException {
		System.out.println("control into validateUser");
		String userName = login.getPhoneNo(); //Keeping user entered values in temporary variables.
		String password = login.getPassword();
		Connection con = null;
		Statement statement = null;
		ResultSet resultSet = null;
		try
		{
			con = DBConnection.createConnection(); //establishing connection
			statement = con.createStatement(); //Statement is used to write queries. Read more about it.
			resultSet = statement.executeQuery("select id,name from STUDENT"); //Here table name is users and userName,password are columns. fetching all the records and storing in a resultSet.

			while(resultSet.next()) // Until next row is present otherwise it return false
			{
				String userNameDB = resultSet.getString("userName"); //fetch the values present in database
				String passwordDB = resultSet.getString("password");
				if(userName.equals(userNameDB) && password.equals(passwordDB))
				{
					return "SUCCESS"; ////If the user entered values are already present in database, which means user has already registered so I will return SUCCESS message.
				}
			}
		} catch(SQLException e)
		{
			System.out.println("Exception in validateUser" + e.getMessage());
			e.printStackTrace();
		}
		return "FAILURE";
	}
}
