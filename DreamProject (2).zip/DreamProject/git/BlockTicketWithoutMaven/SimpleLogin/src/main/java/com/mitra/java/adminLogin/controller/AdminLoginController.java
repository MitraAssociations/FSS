/**
 * 
 */
package com.mitra.java.adminLogin.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.mitra.java.adminLogin.model.AdminLoginBean;
import com.mitra.java.util.DBConnection;

/**
 * @author Deepak
 *
 */
@Controller
public class AdminLoginController {

	@GetMapping(path = "/")
	public String preLogin(Model model) {
		model.addAttribute("loginBean", new AdminLoginBean());
		return "index";
	}

	@PostMapping(path = "/loginProcess")
	public String login(@ModelAttribute("loginBean") AdminLoginBean loginBean) {
		System.out.println("Username: " + loginBean.getUsername());
		System.out.println("Password: " + loginBean.getPassword());
		System.out.println("Phone no: " + loginBean.getPhoneNo());
		DBConnection datasource = new DBConnection();
		String status = datasource.validateUser(loginBean);
		if("SUCCESS".equalsIgnoreCase(status)){
			return "welcome";
		} else {
			return "unauthorizedAccess";
		}
	}

}
