package com.java.spring.web.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.java.spring.web.model.LoginBean;

@Controller
public class LoginController {

	@GetMapping(path = "/")
	public String preLogin(Model model) {
		model.addAttribute("loginBean", new LoginBean());
		return "login";
	}

	@PostMapping(path = "/login")
	public String login(@ModelAttribute("loginBean") LoginBean loginBean) {
		System.out.println("Username: " + loginBean.getUsername());
		System.out.println("Password: " + loginBean.getPassword());
		return "welcome";
	}

}
