/**
 * 
 */
package com.adminLogin.controller;

import com.adminLogin.model.AdminLoginBean;
import com.adminLogin.service.AdminLoginService;

/**
 * @author Imransha
 *
 */
public class AdminLoginController implements AdminLoginService {

	public AdminLoginBean connect(String name, String pwd, String ipaddress) {
		// TODO Auto-generated method stub
		return null;
	}

}
