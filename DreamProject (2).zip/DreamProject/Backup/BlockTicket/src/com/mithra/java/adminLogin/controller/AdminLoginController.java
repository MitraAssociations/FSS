/**
 * 
 */
package com.mithra.java.adminLogin.controller;

import com.mithra.java.adminLogin.model.AdminLoginBean;
import com.mithra.java.adminLogin.service.AdminLoginService;

/**
 * @author Imransham
 *
 */
public class AdminLoginController implements AdminLoginService {

	public AdminLoginBean connect(String name, String pwd, String ipaddress) {
		// TODO Auto-generated method stub
		return null;  
	}

}
